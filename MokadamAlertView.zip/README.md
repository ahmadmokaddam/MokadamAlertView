SCLAlertView-Objective-C
============

By - Ahmad Mokadam

twitter / instagram/facebook
@ahmadmokaddam

My Repo - mokadam.xrepo.co

////////////////////////////////////////

مشروع رسالة لجميع التطبيقات لا يحتاج ميثود ولا شيئ

أن اردت تعديل الوان الأزرار الخ..

في ملف. (SCLAlertView)

////////////////////////////////////////

تأكد من وجودة مكتبه. SCLAlertView في الtheos الخاص بك عبر المسار التالي 

var/theos/include/SCLAlertView/

من ثم تأكد من وجود مكتبة SCLAlertView داخل هذا المشروع

////////////////////////////////////////  



فقط قم بتغيير الباندل لباندل التطبيق الذي تريده 






